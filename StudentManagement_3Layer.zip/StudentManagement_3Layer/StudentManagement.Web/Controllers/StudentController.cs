﻿using StudentManagement.Business.Contracts;
using StudentManagement.Business.Dtos;
using StudentManagement.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace StudentManagement.Web.Controllers
{
    public class StudentController : Controller
    {
        private IStudentBusinessService studentService;

        public StudentController(IStudentBusinessService service)
        {
            studentService = service;
        }

        // GET: Student
        public ActionResult Index(string searchString)
        {
            var student = studentService.GetAllStudents();
            //if (!string.IsNullOrEmpty(searchString))
            //{
            //    student = student.Where(s => s.LastName.ToUpper().Contains(searchString.ToUpper()) 
            //                            || s.FristName.ToUpper().Contains(searchString.ToUpper()));
            //}
            return View(student.ToList());
        }

        // GET: Student/CreateStudent
        public ActionResult CreateStudent()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateStudent(CreateStudentViewModel studentModel)
        {
            try
            {
                StudentDto studentDto = new StudentDto();
                studentDto.FristName = studentModel.FristName;
                studentDto.LastName = studentModel.LastName;
                studentDto.Phone = studentModel.Phone;
                studentDto.DOB = DateTime.Parse(studentModel.DOB);
                studentDto.Address = studentModel.Address;

                if (ModelState.IsValid)
                {
                    studentService.InsertStudent(studentDto);
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }

        public ActionResult EditStudent(Guid id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentDto student = studentService.GetStudentById(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditStudent(UpdateStudentViewModel studentModel)
        {
            try
            {
                
                if (ModelState.IsValid)
                {
                    studentService.UpdateStudent()
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}