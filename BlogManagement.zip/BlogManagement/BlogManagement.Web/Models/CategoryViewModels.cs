﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlogManagement.Web.Models
{
    public class CreateCategoryViewModels
    {
        [Required]
        [Display(Name = "Category name")]
        public string Name { get; set; }
    }

    public class CategoryViewModels
    {
        
        public string Name { get; set; }
    }
}