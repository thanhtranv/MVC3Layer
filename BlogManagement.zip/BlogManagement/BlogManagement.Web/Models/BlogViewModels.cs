﻿using BlogManagement.Business.Dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlogManagement.Web.Models
{
    public class CreateBlogViewModels
    {
        [Required]
        [Display(Name = "Post Title")]
        public string Title { get; set; }

        [Required]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Post Content")]
        public string Content { get; set; }

        [Display(Name = "Attach Image")]
        public string Image { get; set; }

        [Display(Name = "Category")]
        public string Category { get; set; }


    }

    public class BlogViewModels
    {

        public string Title { get; set; }


        public string Content { get; set; }

        public DateTime PostDate { get; set; }


    }
    public class ListPostViewModels
    {
        public List<BlogDto> BlogDto { get; set; }
    }
}