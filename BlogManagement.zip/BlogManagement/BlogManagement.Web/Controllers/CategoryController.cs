﻿using BlogManagement.Business.Contracts;
using BlogManagement.Business.Dtos;
using BlogManagement.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BlogManagement.Web.Controllers
{
    public class CategoryController : Controller
    {
        private ICategoryBusinessService categoryService;

        public CategoryController(ICategoryBusinessService service)
        {
            categoryService = service;
        }

        // GET: Category
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CreateCategoryViewModels categoryModel)
        {
            try
            {
                CategoryDto categoryDto = new CategoryDto();
                categoryDto.Name = categoryModel.Name;

                if (ModelState.IsValid)
                {
                    var category = categoryService.GetCategoryByName(categoryModel.Name);
                    if (category == null)
                    {
                        categoryService.InsertCategory(categoryDto);
                        return Content("<script>alert('Successfully inserted')</script>");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Category existed");

                    }
                }
            }
            catch (DataException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }

    }
}