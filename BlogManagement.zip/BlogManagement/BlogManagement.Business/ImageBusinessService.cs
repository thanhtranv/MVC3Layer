﻿using AutoMapper;
using BlogManagement.Business.Contracts;
using BlogManagement.Business.Dtos;
using BlogManagement.Data.Contracts;
using BlogManagement.Data.Entities;
using System;
using System.Collections.Generic;


namespace BlogManagement.Business
{
    public class ImageBusinessService : BaseBusinessService, IImageBusinessService
    {
        private IRepository<Image> imageRepository;

        public ImageBusinessService(IRepository<Image> repo)
        {
            imageRepository = repo;
        }

        public void DeleteImage(ImageDto imageDto)
        {
            var image = Mapper.Map<Image>(imageDto);

            imageRepository.Delete(image);
            imageRepository.SaveChanges();
        }

        public IList<ImageDto> GetAllImages()
        {
            var image = imageRepository.GetAll();
            var imageDtos = (IList<ImageDto>)Mapper.Map(image, image.GetType(), typeof(IList<ImageDto>));
            return imageDtos;
        }

        public ImageDto GetImageById(Guid Id)
        {
            var image = imageRepository.GetById(Id);
            return Mapper.Map<Image, ImageDto>(image);
        }

        public ImageDto InsertImage(ImageDto imageDto)
        {
            var image = Mapper.Map<Image>(imageDto);
            image = imageRepository.Insert(image);
            imageRepository.SaveChanges();

            return Mapper.Map<Image, ImageDto>(image);
        }

        //public IList<ImageDto> SearchCategoryByName(string categoryName, int pageIndex, int pageSize, out int total)
        //{
        //    var category = categoryRepository.Search(p => p.Name.Contains(categoryName), o => o.Name, pageIndex, pageSize, out total);
        //    var categoryDtos = (IList<CategoryDto>)Mapper.Map(category, category.GetType(), typeof(IList<CategoryDto>));

        //    return categoryDtos;
        //}

        public void UpdateImage(ImageDto imageDto)
        {
            var image = Mapper.Map<Image>(imageDto);

            imageRepository.Update(image);
            imageRepository.SaveChanges();
        }
    }
}
